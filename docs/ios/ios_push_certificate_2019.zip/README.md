# Datos iOS

Certificados generados en: [Push Notification Certificate Wizard](https://onesignal.com/provisionator)

* file .P12 Password is: gvrbpbgqat
